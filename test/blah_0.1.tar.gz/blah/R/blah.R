blah <- function() {
  cat("hooray, you used the blah package")
}
